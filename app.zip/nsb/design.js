// (c) 2016 NS BASIC Corporation. All rights reserved.
var NSB = NSB || {};
NSB.designEditor = {
    _frame_prefix: '-nsb-frame-',
    _map: {},
    _selection: [],
    _loaded: false,
    _uuid: null,
    _drag: false,
    _grab_classes: null,

    get map() { return JSON.stringify(this._map); },

    get loaded() { return JSON.stringify(this._loaded); },

    get uuid() { return JSON.stringify(this._uuid); },
    set uuid(u) { return this._uuid = u; },

    createFrame: function(element_name, rect, resize) {
        var i,
            grab,
            frame = document.createElement('div');

        frame.id = NSB.designEditor._frame_prefix+element_name;
        frame.classList.add(NSB.designEditor._frame_prefix+'base');
        frame.classList.add(NSB.designEditor._frame_prefix+'selector');

        if (resize) {
            for (i = 0; i < NSB.designEditor._grab_classes.length; i++) {
                grab = document.createElement('div');
                grab.classList.add(NSB.designEditor._frame_prefix+'base');
                grab.classList.add(NSB.designEditor._frame_prefix+'grab-handle');
                grab.classList.add(NSB.designEditor._grab_classes[i][0]);
                grab.classList.add(NSB.designEditor._grab_classes[i][1]);
                frame.appendChild(grab);
            }
        }

        document.body.appendChild(frame);
        NSB.designEditor.createPosLines(element_name, rect);
        NSB.designEditor.setFrameRect(element_name, rect);
        return frame;
    },

    createPosLines: function(element_name, rect) {
        var pos_lines_vert = document.createElement('div'),
            pos_lines_horiz = document.createElement('div');

        pos_lines_horiz.id = NSB.designEditor._frame_prefix+'pos-lines-horiz-'+element_name;
        pos_lines_horiz.classList.add(NSB.designEditor._frame_prefix+'base');
        pos_lines_horiz.classList.add(NSB.designEditor._frame_prefix+'pos-lines-horiz');

        pos_lines_vert.id = NSB.designEditor._frame_prefix+'pos-lines-vert-'+element_name;
        pos_lines_vert.classList.add(NSB.designEditor._frame_prefix+'base');
        pos_lines_vert.classList.add(NSB.designEditor._frame_prefix+'pos-lines-vert');

        document.body.appendChild(pos_lines_horiz);
        document.body.appendChild(pos_lines_vert);
        NSB.designEditor.setFrameRect(element_name, rect);
        return true;
    },

    getElementRect: function(element) {
        if (typeof element.getDesignFrameRect === 'undefined') {
            element.getDesignFrameRect = element.getBoundingClientRect;
        }
        rect = element.getDesignFrameRect();
        return [rect.left, rect.top, rect.width, rect.height];
    },

    onLoad: function() {
        var i,
            j,
            style,
            forms,
            kids;

        NSB.designEditor._grab_classes = [[NSB.designEditor._frame_prefix+'grab-top',
                                           NSB.designEditor._frame_prefix+'grab-left'],
                                          [NSB.designEditor._frame_prefix+'grab-top',
                                           NSB.designEditor._frame_prefix+'grab-center'],
                                          [NSB.designEditor._frame_prefix+'grab-top',
                                           NSB.designEditor._frame_prefix+'grab-right'],
                                          [NSB.designEditor._frame_prefix+'grab-middle',
                                           NSB.designEditor._frame_prefix+'grab-left'],
                                          [NSB.designEditor._frame_prefix+'grab-middle',
                                           NSB.designEditor._frame_prefix+'grab-right'],
                                          [NSB.designEditor._frame_prefix+'grab-bottom',
                                           NSB.designEditor._frame_prefix+'grab-left'],
                                          [NSB.designEditor._frame_prefix+'grab-bottom',
                                           NSB.designEditor._frame_prefix+'grab-center'],
                                          [NSB.designEditor._frame_prefix+'grab-bottom',
                                           NSB.designEditor._frame_prefix+'grab-right']];

        // Build styles
        style = document.createElement('style');
        style.innerHTML = ['.'+NSB.designEditor._frame_prefix+'base {',
                           '  position: absolute;',
                           '  z-index: 2147483647;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'selector {',
                           '  border: 1px dotted blue;',
                           '  background-color: rgba(0, 0, 255, 0.1);',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'pos-lines-horiz {',
                           '  border-top: 1px dotted blue;',
                           '  border-bottom: 1px dotted blue;',
                           '  width: 1000%;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'pos-lines-vert {',
                           '  border-left: 1px dotted blue;',
                           '  border-right: 1px dotted blue;',
                           '  height: 1000%;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'grab-handle {',
                           '  width: 5px;',
                           '  height: 5px;',
                           '  border: 1px solid black;',
                           '  background-color: white;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'grab-top {',
                           '  top: -4px;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'grab-bottom {',
                           '  bottom: -4px;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'grab-left {',
                           '  left: -4px;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'grab-right {',
                           '  right: -4px;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'grab-center {',
                           '  left: 50%;',
                           '  margin-left: -3px',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'grab-middle {',
                           '  top: 50%;',
                           '  margin-top: -3px;',
                           '}',
                           '.'+NSB.designEditor._frame_prefix+'hide {',
                           '  display: none;',
                           '}',
                           '/* blue outlines to make hard to see elements easier to see */',
                           'canvas, img, audio, video, .adsense, progress {',
                           '  border: 1px solid blue;',
                           '}',
                           '.adsense {',
                           '  display: block !important;',
                           '}',
                           '/* hide all forms to begin with, in design mode */',
                           'div.nsb-form {',
                           '  display: none;',
                           '}',
                           '/* disable scrollbars */',
                           'body {',
                           '  overflow: hidden;',
                           '}',
                           '/* kill transitions so we can draw accurate frames */',
                           'body * {',
                           '  transition: none !important;',
                           '}'].join('\n');
        document.getElementsByTagName('head')[0].appendChild(style);

        // Create a map of nsb-form objects
        forms = document.getElementsByClassName('nsb-form');
        for (i = 0; i < forms.length; i++) {
            kids = forms[i].getElementsByTagName('*');
            for (j = 0; j < kids.length; j++) {
                if (typeof kids[j].id !== 'undefined')
                    NSB.designEditor._map[kids[j].id] = NSB.designEditor.getElementRect(kids[j])
            }
        }

        NSB.designEditor._loaded = true;
    },

    select: function(elements) {
        var i,
            frame,
            rect;

        // remove current selection
        for (i = 0; i < NSB.designEditor._selection.length; i++) {
            frame = document.getElementById(NSB.designEditor._frame_prefix+NSB.designEditor._selection[i][0]);
            if (frame) document.body.removeChild(frame);
            frame = document.getElementById(NSB.designEditor._frame_prefix+'pos-lines-horiz-'+NSB.designEditor._selection[i][0]);
            if (frame) document.body.removeChild(frame);
            frame = document.getElementById(NSB.designEditor._frame_prefix+'pos-lines-vert-'+NSB.designEditor._selection[i][0]);
            if (frame) document.body.removeChild(frame);
        }

        // create new selection, as necessary
        for (i = 0; i < elements.length; i++) {
            rect = NSB.designEditor._map[elements[i][0]];
            NSB.designEditor.createFrame(elements[i][0], rect, elements[i][1]);
        }
        NSB.designEditor._selection = elements;
        return JSON.stringify(NSB.designEditor._selection);
    },

    removePosLines: function() {
        var i,
            frame;

        for (i = 0; i < NSB.designEditor._selection.length; i++) {
            frame = document.getElementById(NSB.designEditor._frame_prefix+'pos-lines-horiz-'+NSB.designEditor._selection[i][0]);
            if (frame) document.body.removeChild(frame);
            frame = document.getElementById(NSB.designEditor._frame_prefix+'pos-lines-vert-'+NSB.designEditor._selection[i][0]);
            if (frame) document.body.removeChild(frame);
        }

        return true;
    },

    setFrameRect: function(element_name, rect, drag) {
        var i,
            handles,
            frame = document.getElementById(NSB.designEditor._frame_prefix+element_name),
            pos_lines_horiz = document.getElementById(NSB.designEditor._frame_prefix+'pos-lines-horiz-'+element_name),
            pos_lines_vert = document.getElementById(NSB.designEditor._frame_prefix+'pos-lines-vert-'+element_name);
        drag = (typeof drag === 'undefined') ? false : drag;

        if (drag != NSB.designEditor._drag) {
            handles = document.getElementsByClassName(NSB.designEditor._frame_prefix+'grab-handle');
            NSB.designEditor._drag = drag;
            for (i = 0; i < handles.length; i++) {
                handles[i].classList.toggle(NSB.designEditor._frame_prefix+'hide');
            }
        }

        if (frame) {
            frame.style.cssText = 'left:'+(rect[0] - 1)+'px; top:'+(rect[1] - 1)+'px; ';
            frame.style.cssText += 'width:'+rect[2]+'px; height:'+rect[3]+'px; ';
            if (pos_lines_horiz && pos_lines_vert) {
                pos_lines_horiz.style.cssText = 'top:'+(rect[1] - 1)+'px; height:'+rect[3]+'px; ';
                pos_lines_vert.style.cssText = 'left:'+(rect[0] - 1)+'px; width:'+rect[2]+'px; ';
            }
            return JSON.stringify(frame.style.cssText);
        }
        return JSON.stringify('No frame!');
    }
};

window.addEventListener('load', function() {
    // we need to defer this just long enough to let the other load
    // events fire first - thank goodness for single threading
    setTimeout(NSB.designEditor.onLoad, 1);
}, false);
